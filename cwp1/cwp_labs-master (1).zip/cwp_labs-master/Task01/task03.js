const name=process.argv[2];
if(name!=null)
console.log(`Hello, ${name}`);
else
console.log('Hello, who are you?');